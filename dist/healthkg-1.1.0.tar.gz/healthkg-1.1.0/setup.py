# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['healthkg']

package_data = \
{'': ['*']}

install_requires = \
['configparser>=5.3.0,<6.0.0',
 'en_core_sci_lg @ '
 'https://s3-us-west-2.amazonaws.com/ai2-s2-scispacy/releases/v0.5.1/en_core_sci_lg-0.5.1.tar.gz',
 'neo4j==4.4.2',
 'numpy>=1.21.6,<2.0.0',
 'pandas>=1.3.5,<2.0.0',
 'scispacy>=0.5.1,<0.6.0',
 'streamlit>=1.13.0,<2.0.0']

setup_kwargs = {
    'name': 'healthkg',
    'version': '1.1.0',
    'description': 'Health Knowledge Graph',
    'long_description': '# Health Knowledge Graph (KG)\n\nA Health KG is a collection of interlinked descriptions of health-related entities and relationships. It is created to semantically link knowledge together multiple credible sources, to normalize for fact finding, eliminating mislabels, typos, discrepancies and information ambiguity. From Health KG, Q&A systems can be powered by dense knowledge graph can turn questions into explorations of knowledge.\n\n![image](https://user-images.githubusercontent.com/7111764/200758357-813d9c68-5061-4271-9cd5-cd0e5f625167.png)\n\n\n## Dependencies\n\n### poetry\n```pip install poetry```\n\n## Setup\n\nGo to the folder that contains the toml file and run ```poetry install``` in your terminal, this will setup and install all the required dependencies and libraries.\n\n## Running Application\n\nGo to the subfolder that contains the py file and run ```poetry run streamlit run healthhub_app.py``` in your terminal to launch the streamlit app.\n\n## Building Package\n\nGo to the folder that contains the toml file and run ```poetry build```\n',
    'author': 'Benjamin Chu',
    'author_email': 'bensabenteuer@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<3.9.7',
}


setup(**setup_kwargs)
